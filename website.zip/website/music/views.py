from django.http import HttpResponse,Http404
from .models import Album, Song
from django.shortcuts import render

def welcome(request):
    return render(request ,'music_templates/home.html')

def index(request):
    #yield HttpResponse("<h1 align="centre">WELCOME TO MUSIC HOWMEPAGE</h1>")

    album = Album.objects.all()
    for i in album:
        context = {'album': album}
    return render(request, 'music_templates/index.html', context)


def detail(request, album_id):
    try:
        album = Album.objects.get(pk=album_id)
    except Album.DoesNotExist:
        raise Http404("Album does not exist")
    return render(request, 'music_templates/details.html', {'album': album})
