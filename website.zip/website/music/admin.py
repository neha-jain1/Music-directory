from .models import Album,Song
from django.contrib import admin

admin.site.register(Album)
admin.site.register(Song)
