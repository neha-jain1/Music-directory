from django.conf.urls import url
from . import views

urlpatterns = [
    # response for music/
    url(r'^home/',views.welcome),
    url(r'^$', views.index, name='index'),

    # response for particular album based on their id
    url(r'^(?P<album_id>[0-9]+)/$', views.detail, name='detail'),

]
